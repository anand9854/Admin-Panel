from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http.response import JsonResponse
from .models import Module_Master
from .serializers import ModuleSerializer
from django.http.response import Http404
from rest_framework.response import Response

# Create your views here.

class ModuleView(APIView):
	def post (self, request):
		data = request.data
		serializer = ModuleSerializer(data=data)

		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Added Successfully", safe=False)
		return JsonResponse("Failed to Add the Record", safe=False)
	
	def get_Module_Master(self, pk):
		try:
			Module = Module_Master.objects.get(ID=pk)
			return Module
		except Module.DoesNotExist:
			raise Http404

	def get(self, request, pk=None):
		if pk:
			data = self.get_Module_Master(pk)
			serializer = ModuleSerializer(data)
		else:
			data = Module_Master.objects.all()
			serializer = ModuleSerializer(data, many = True)
		return Response(serializer.data)
	def put(self, request, pk=None):
    		module_to_update = Module_Master.objects.get(ID=pk)
    		serializer = ModuleSerializer(instance=module_to_update, data=request.data, partial=True)

    		if serializer.is_valid():
        		serializer.save()
        		return JsonResponse("Record updated Successfully", safe=False)
    		return JsonResponse("Failed To Update Record")
	def delete(self, request, pk):
		module_to_delete = Module_Master.objects.get(ID=pk)
		module_to_delete.delete()
		return JsonResponse("Record deleted Successfully", safe=False)



