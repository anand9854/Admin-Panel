from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http.response import JsonResponse
from .models import Module_Master, Form_Master, Rights_User, User_Model
from .serializers import ModuleSerializer, FormSerializer, UserSerializer, UserModelSerializer
from django.http.response import Http404
from rest_framework.response import Response

# Create your views here.
	  

class ModuleView(APIView):
	def post (self, request):
		data = request.data
		serializer = ModuleSerializer(data=data)

		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Added Successfully", safe=False)
		return JsonResponse("Failed to Add the Record", safe=False)
	
	def get_Module_Master(self, pk):
		try:
			Module = Module_Master.objects.get(ID=pk)
			return Module
		except Module.DoesNotExist:
			raise Http404

	def get(self, request, pk=None):
		if pk:
			data = self.get_Module_Master(pk)
			serializer = ModuleSerializer(data)
		else:
			data = Module_Master.objects.all()
			serializer = ModuleSerializer(data, many = True)
		return Response(serializer.data)
	def put(self, request, pk=None):
    		module_to_update = Module_Master.objects.get(ID=pk)
    		serializer = ModuleSerializer(instance=module_to_update, data=request.data, partial=True)

    		if serializer.is_valid():
        		serializer.save()
        		return JsonResponse("Record updated Successfully", safe=False)
    		return JsonResponse("Failed To Update Record")
	def delete(self, request, pk):
		module_to_delete = Module_Master.objects.get(ID=pk)
		module_to_delete.delete()
		return JsonResponse("Record deleted Successfully", safe=False)



class FormView(APIView):
	def post(self, request):
		data = request.data
		serializer = FormSerializer(data=data)
		
		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record added successfully", safe=False)
		return JsonResponse("Failed to add Record", safe=False)
	def get_FormMaster(self, rk):
		try:
			Form = Form_Master.objects.get(ID=rk)
			return Form
		except  Form_Master.DoesNotExist:
			raise Http404
	def get(self, request, rk=None):
		if rk:
			data = self.get_FormMaster(rk)
			serializer = FormSerializer(data)
		else:
			data = Form_Master.objects.all()
			serializer = FormSerializer(data, many=True)
		return Response(serializer.data)		
	def put(self, request, rk=None):
		Form_to_update = Form_Master.objects.get(ID=rk)
		serializer = FormSerializer(instance=Form_to_update, data = request.data, partial=True)
		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Update Successfully", safe=False)
		return JsonResponse("Failed to Update Record")
	def delete(self, request, rk):
		Form_to_delete = Form_Master.objects.get(ID=rk)
		Form_to_delete.delete()
		return JsonResponse("Record Deleted successfully", safe=False)
class RightsView(APIView):
	def post(self, request):
		data = request.data
		serializer = UserSerializer(data=data)
		
		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Added Successfully", safe=False)
		return JsonResponse("Failed to Add the Record", safe=False)
	def get_UserMaster(self, rk):
		try:
			Form = Rights_User.objects.get(ID=rk)
			return Form
		except  Rights_User.DoesNotExist:
			raise Http404
	def get(self, request, rk=None):
		if rk:
			data = self.get_UserMaster(rk)
			serializer = UserSerializer(data)
		else:
			data = Rights_User.objects.all()
			serializer = UserSerializer(data, many=True)
		return Response(serializer.data)
	def put(self, request, rk=None):
		User_to_update = Rights_User.objects.get(ID=rk)
		serializer = UserSerializer(instance=User_to_update, data = request.data, partial=True)
		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Update Successfully", safe=False)
		return JsonResponse({"error": "Failed to Update Record"}, safe=False)

	def delete(self, request, rk):
		Form_to_delete = Rights_User.objects.get(ID=rk)
		Form_to_delete.delete()
		return JsonResponse("Record Deleted successfully", safe=False)


class UserModelView(APIView):
	def post (self, request):
		data = request.data
		serializer = UserModelSerializer(data=data)

		if serializer.is_valid():
			serializer.save()
			return JsonResponse("Record Added Successfully", safe=False)
		return JsonResponse("Failed to Add the Record", safe=False)
	
	def get_User_Model(self, pk):
		try:
			Model = User_Model.objects.get(ID=pk)
			return Model
		except User_Model.DoesNotExist:
			raise Http404

	def get(self, request, pk=None):
		if pk:
			data = self.get_User_Model(pk)
			serializer = UserModelSerializer(data)
		else:
			data = User_Model.objects.all()
			serializer = UserModelSerializer(data, many = True)
		return Response(serializer.data)
	def put(self, request, pk=None):
    		module_to_update = User_Model.objects.get(ID=pk)
    		serializer = UserModelSerializer(instance=module_to_update, data=request.data, partial=True)

    		if serializer.is_valid():
        		serializer.save()
        		return JsonResponse("Record updated Successfully", safe=False)
    		return JsonResponse("Failed To Update Record")
	def delete(self, request, pk):
		module_to_delete = User_Model.objects.get(ID=pk)
		module_to_delete.delete()
		return JsonResponse("Record deleted Successfully", safe=False)