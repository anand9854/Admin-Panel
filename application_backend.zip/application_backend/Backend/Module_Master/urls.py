from django.urls import path
from .views import ModuleView, FormView, RightsView, UserModelView

urlpatterns = [
    path('Module_Master/', ModuleView.as_view()),
    path('Module_Master/<int:pk>/', ModuleView.as_view()),
    path('Forms/', FormView.as_view()),
    path('Forms/<int:rk>/', FormView.as_view()),		
    path('Rights/', RightsView.as_view()),
    path('Rights/<int:rk>/', RightsView.as_view()),
    path('User/', UserModelView.as_view()),
    path('User/<int:pk>/', UserModelView.as_view()),
]