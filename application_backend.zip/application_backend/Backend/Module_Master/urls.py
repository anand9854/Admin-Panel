from django.urls import path
from .views import ModuleView

urlpatterns = [
    path('Module_Master/', ModuleView.as_view()),
    path('Module_Master/<int:pk>/', ModuleView.as_view())
]