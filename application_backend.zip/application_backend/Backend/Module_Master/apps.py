from django.apps import AppConfig


class ModuleMasterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Module_Master'
