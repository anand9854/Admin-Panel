from rest_framework import serializers 
from .models import Module_Master, Form_Master, Rights_User

class ModuleSerializer(serializers.ModelSerializer):
	class Meta:
		model = Module_Master
		fields = ('ID',
			  'Module_name')


class FormSerializer(serializers.ModelSerializer):
	class Meta:
		model = Form_Master
		fields = ('ID',
		          'Modulename',
			  'Formname',
			  'Formcode'	
			)

class UserSerializer(serializers.ModelSerializer):
	class Meta:
			model = Rights_User
			fields = (
				'ID',
				'UserRole',
				'Formname',
				'Add',
				'Delete',
				'View',
				'Post',
				'Menu',
				'Others'
			)
