from rest_framework import serializers 
from .models import Module_Master

class ModuleSerializer(serializers.ModelSerializer):
	class Meta:
		model = Module_Master
		fields = ('ID',
			  'Module_name')