from django.contrib import admin
from .models import Module_Master, Form_Master, Rights_User, User_Model

# Register your models here.

admin.site.register(Module_Master)
admin.site.register(Form_Master)

class Useradmin(admin.ModelAdmin):
	list_display = ("ID","UserRole","Formname","Add","Delete","View","Post","Menu","Others")
admin.site.register(Rights_User, Useradmin)

admin.site.register(User_Model)
