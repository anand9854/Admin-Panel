from django.contrib import admin
from .models import Module_Master, Form_Master, Rights_User

# Register your models here.

admin.site.register(Module_Master)
admin.site.register(Form_Master)

class Useradmin(admin.ModelAdmin):
	list_display = ("ID","Formname","Add","Delete","View","Post","Menu","Others")
admin.site.register(Rights_User, Useradmin)