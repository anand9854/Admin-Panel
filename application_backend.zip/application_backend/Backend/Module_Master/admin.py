from django.contrib import admin
from .models import Module_Master

# Register your models here.

models_list =[Module_Master]
admin.site.register(models_list)