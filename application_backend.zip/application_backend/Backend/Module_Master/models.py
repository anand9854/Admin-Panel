from django.db import models

class Module_Master(models.Model):
    ID = models.AutoField(primary_key=True)
    Module_name = models.CharField(max_length=255)

class Form_Master(models.Model):
    ID = models.AutoField(primary_key=True)
    Modulename = models.CharField(max_length=255)
    Formname = models.CharField(max_length=100)
    Formcode = models.IntegerField()

class Rights_User(models.Model):
    ID = models.AutoField(primary_key=True)
    UserRole = models.CharField(max_length=100)
    Formname = models.CharField(max_length=100)  
    Add = models.BooleanField(default=False)
    Delete = models.BooleanField(default=False)
    View = models.BooleanField(default=False)
    Post = models.BooleanField(default=False)
    Menu = models.BooleanField(default=False)
    Others = models.BooleanField(default=False)
