from django.db import models

# Create your models here.

class Module_Master(models.Model):
	ID = models.AutoField(primary_key=True)
	Module_name = models.CharField(max_length=255)
	