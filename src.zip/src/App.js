import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Manage from './components/Manage';
import StatFullTemplate from './components/Module';
import Login from './Navigations/Login';
import ManageForm from './components/Form_component/Manage_Form';
import UserManagement from './components/UserRights/UserManagement';

function App() {
	return(
		<BrowserRouter>
			<Routes>
				<Route path="/" element={<Login/>}/>										
				<Route path="/Dashboard" element={<StatFullTemplate/>}/>					
				<Route path="/Manage" element={<Manage/>}/>
				<Route path="/Form_master" element = {<ManageForm/>}></Route>
				<Route path="/Rights" element ={<UserManagement/>}></Route>
				
			</Routes>
		</BrowserRouter>	
	);
}

export default App;