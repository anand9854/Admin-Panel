import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Manage from './components/Manage';
import SearchAppBar from './Navigations/AppHead';
import StatFullTemplate from './components/Module';


function App() {
	return(
		<BrowserRouter>
			<SearchAppBar/>
			<Routes>
												
				<Route path='/' element={<StatFullTemplate/>}/>					
				<Route path="/Manage" element={<Manage/>}/>
				
					
			</Routes>
		</BrowserRouter>	
	);
}

//<Route path="/" element={<StatFullTemplate/>}/>

export default App;