import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Manage from './components/Manage';
//import SearchAppBar from './Navigations/AppHead';
import StatFullTemplate from './components/Module';
import Login from './Navigations/Login';
import Logout from './Navigations/Logout';


function App() {
	return(
		<BrowserRouter>
			
			<Routes>
				<Route path="/" element={<Login/>}/>										
				<Route path="/Dashboard" element={<StatFullTemplate/>}/>					
				<Route path ="/Logout" element={<Logout/>}/>
				<Route path="/Manage" element={<Manage/>}/>
				
					
			</Routes>
		</BrowserRouter>	
	);
}

//<Route path="/" element={<StatFullTemplate/>}/>
//<SearchAppBar/>
export default App;