import React from "react";
import {Modal, Col, Row, Form, Button} from 'react-bootstrap';
import {updateForms} from '../../services/FormService';


const Modalupdate = (props) =>{
    const handleSubmit = (e) =>{
        e.preventDefault();
        updateForms(props.module_form.ID, e.target).then((result) =>{
            alert(result)
            props.setUpdated(true);
        },
        (error) =>{
            alert("Failed to Update Record")
        })
    }
    return(
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title=vcenter">
                        Update Record
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row className="justify-content-center">
                        <Col sm={4}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="Modulename">
                                    <Form.Label>Module name</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        name="Modulename" 
                                        required defaultValue={props.module_form.Modulename}
                                        placeholder=""
                                    />
                                </Form.Group>
                                <Form.Group controlId="Formname">
                                    <Form.Label>Form name</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        name="Formname" 
                                        required defaultValue={props.module_form.Formname}
                                        placeholder=""
                                    />
                                </Form.Group>
                                <Form.Group controlId="Formcode">
                                    <Form.Label>Form Code</Form.Label>
                                    <Form.Control 
                                        type="number" 
                                        name="Formcode" 
                                        required defaultValue={props.module_form.Formcode}
                                        placeholder=""
                                    />
                                </Form.Group>
                                <Form.Group>
                                    <p></p>
                                    <Button variant="primary" type="submit">Submit</Button>
                                </Form.Group>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" type="submit" onClick={props.onHide}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
};

export default Modalupdate;