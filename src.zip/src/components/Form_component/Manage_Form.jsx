import React, {useState, useEffect } from 'react';
import { Table } from 'react-bootstrap';
import {getForms, deleteForms} from  '../../services/FormService';
import { RiDeleteBin5Line } from 'react-icons/ri';
import { FaEdit } from 'react-icons/fa';
import AddModalform from './AddModal';
import Modalupdate from './Modalupdate';
import ClippedDrawer from '../../Navigations/AppHead';
import {Button,ButtonToolbar } from 'react-bootstrap';
import '../../App.css';
import LoupeIcon from '@mui/icons-material/Loupe';
const ManageForm = () =>{
    const [moduleform, setModuleform] = useState([]);
    const [addModalShow, setAddModalShow] = useState(false);
    const [editModalShow, setEditModalShow] = useState(false);
    const [editModuleform, setEditModuleform] = useState([]);
    const [isUpdated, setIsUpdated] = useState(false);
    useEffect(()=> {
        let mounted = true;
        if (moduleform.length && !isUpdated)    {
            return;
        }
        getForms().then(data => {
            if(mounted){
                setModuleform(data)
            }
        })
        return () => {
            mounted = false 
            setIsUpdated(false);
        }
    }, [isUpdated, moduleform])


    const handleUpdate = (e, formid) =>{
        e.preventDefault();
        setEditModalShow(true);
        setEditModuleform(formid);
    };

    const handleAdd = (e) => {
        e.preventDefault();
        setAddModalShow(true);
    };

    const handleDelete = (e, ID) => {
        if (window.confirm('Are you sure ?')){
            e.preventDefault();
            deleteForms(ID).then((result) =>{
                alert(result);
                setIsUpdated(true);

            },
            (error)=>{
                alert("Failed to Add Record");
            })
        }   


    }

    let AddModelClose=()=>setAddModalShow(false);
    let EditModelClose=()=>setEditModalShow(false);

    return(
        <div className="container-fluid side-container">
            <ClippedDrawer/>
            <div className="row side-row">
                <p id = "manage_form"></p>
                <ButtonToolbar>
                    <Button variant="success" onClick={handleAdd} style={{position:"relative", top:"5px",width:'5.7%', left:"1230px"}}>
                    <LoupeIcon/><label style={{ position: "relative", top: "2px", left: "5px" }}>Add</label> 
                    </Button>{" "}
                    <AddModalform 
                        show={addModalShow}
                        setUpdated={setIsUpdated}
                        onHide={AddModelClose}
                    />

                    
                </ButtonToolbar>
                <Table striped bordered hover className="react-bootstrap-table" 
                style={
                    { 
                        position: "relative", 
                        left: "169px", 
                        top: "30px", 
                        width: "88%" 
                    }
                    }>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Module Name</th>
                            <th>Form Name</th>
                            <th>Form Code</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        {moduleform.map ((formid) =>
                        <tr key={formid.id}>
                            <td>{formid.ID}</td>
                            <td>{formid.Modulename}</td>
                            <td>{formid.Formname}</td>
                            <td>{formid.Formcode}</td>
                            <td>
                                <Button 
                                    className="mr-2" 
                                    variant="danger" 
                                    onClick={event => handleDelete(event, formid.ID)}
                                >
                                    <RiDeleteBin5Line />
                                </Button>
                                <span>&nbsp;&nbsp;&nbsp;</span>
                                <Button 
                                    className="mr-2" 
                                    variant="primary" 
                                    onClick={event => handleUpdate(event, formid)}
                                >
                                    <FaEdit />
                                </Button>                           
                                <Modalupdate 
                                    show={editModalShow} 
                                    module_form={editModuleform}
                                    setUpdated={setIsUpdated}
                                    onHide={EditModelClose}
                                />
                            </td>
                        </tr>
                        ) 
                        }
                    </tbody>
                </Table>
                
            </div>
            
        </div>
        
        )



}

export default ManageForm;