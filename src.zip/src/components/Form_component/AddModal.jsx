import React, { useState, useEffect } from 'react';
import { Modal, Col, Row, Form, Button } from 'react-bootstrap';
import { addForms } from '../../services/FormService';
import { getModule } from '../../services/ModuleService';

const AddModalform = (props) => {
    const [module, setModule] = useState([]);
    const [isUpdated, setIsUpdated] = useState(false);

    useEffect(() => {
        let mounted = true;
        if (module.length && !isUpdated) {
            return;
        }
        getModule().then((data) => {
            if (mounted) {
                setModule(data);
            }
        });
        return () => {
            mounted = false;
            setIsUpdated(false);
        };
    }, [isUpdated, module]);

    const handleSubmit = (e) => {
        e.preventDefault();
        addForms(e.target).then(
            (result) => {
                alert(result);
                props.setUpdated(true);
            },
            (error) => {
                alert("Failed to Add Record");
            }
        );
    }

    return (
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Fill in the Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row className="justify-content-center">
                        <Col sm={6}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="Modulename">
                                    <Form.Label>Module Name</Form.Label>
                                    <Form.Control as="select" name="Modulename" required>
                                        {module.map((mod) => (
                                            <option key={mod.id}>{mod.Module_name}</option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>
                                <Form.Group controlId="Formname">
                                    <Form.Label>Form Name</Form.Label>
                                    <Form.Control type="text" name="Formname" required placeholder="Enter Form Name" />
                                </Form.Group>
                                <Form.Group controlId="Formcode">
                                    <Form.Label>Form Code</Form.Label>
                                    <Form.Control type="number" name="Formcode" required placeholder="Enter Form Code" />
                                </Form.Group><p></p>
                                <Button variant="primary" type="submit" >
                                    Submit
                                </Button>
                            </Form>
                        </Col>
                        
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default AddModalform;
