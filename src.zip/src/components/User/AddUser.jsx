import React from "react";
import { Button, Form, Modal,Col, Row } from "react-bootstrap";
import {addUserModel} from '../../services/UserModelService';


const AddUserModel = (props) =>{


    const handleSubmit = (e) =>{
        e.preventDefault();
        addUserModel(e.target)
        .then((result)=>{
            alert(result);
            props.setUpdated(true);
        },
        (error)=>{
            alert("Failed to Add Record");
        });        
    }
    

    return(
        <div className="container">

            <Modal 
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            
            >
                <Modal.Header closeButton>
                    <Modal.Title>
                        Fill Module Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row>
                        <Col sm={2}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="Username" style={{width:"250px"}}>
                                    <Form.Label>
                                        User Name
                                    </Form.Label>
                                    <Form.Control type="text" name="Username" required placeholder="Enter Username"/>
                                </Form.Group>
                                <Form.Group controlId="Password" style={{width:"250px"}}>
                                    <Form.Label>
                                        Password 
                                    </Form.Label>
                                    <Form.Control type="Password" name="Password" required placeholder="Enter Password"/>
                                </Form.Group>
                                <Form.Group>
                                    <p></p>
                                    <Button variant="primary" type="submit">
                                        Submit
                                    </Button>
                                </Form.Group>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide}>Close</Button>                    
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default AddUserModel;