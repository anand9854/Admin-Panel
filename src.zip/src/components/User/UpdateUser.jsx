import React from "react";
import { Button, Form, Modal, Col, Row } from "react-bootstrap";
import { updateUserModel } from '../../services/UserModelService';

const UpdateUser = (props) => {

    const handleSubmit = (e) => {
        e.preventDefault();

        const formData = new FormData(e.target); 

        const updatedUserData = {
            ID: props.module.ID,
            Username: formData.get('Username'), 
        };

        updateUserModel(props.module.ID, updatedUserData)
            .then((result) => {
                alert(result);
                props.setUpdated(true);
            })
            .catch((error) => {
                alert("Failed to Update Record");
                console.error('Update error:', error); 
            });
    };

    return (
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title>
                        Update Module Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row>
                        <Col sm={2}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="Username" style={{ width: "250px" }}>
                                    <Form.Label>Username</Form.Label>
                                    {props.module && (
                                        <Form.Control
                                            type="text"
                                            name="Username"
                                            defaultValue={props.module.Username}
                                        />
                                    )}
                                </Form.Group>
                                <Form.Group>
                                    <p></p>
                                    <Button variant="primary" type="submit">
                                        Submit
                                    </Button>
                                </Form.Group>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default UpdateUser;
