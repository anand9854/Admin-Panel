import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const monthData = {
  January: [
    { name: 'Week 1', Sales: 100 },
    { name: 'Week 2', Sales: 200 },
    { name: 'Week 3', Sales: 150 },
    { name: 'Week 4', Sales: 278 }
  ],
  February: [
    { name: 'Week 1', Sales: 120 },
    { name: 'Week 2', Sales: 180 },
    { name: 'Week 3', Sales: 210 },
    { name: 'Week 4', Sales: 250 }
  ],
  March: [
    { name: 'Week 1', Sales: 140 },
    { name: 'Week 2', Sales: 120 },
    { name: 'Week 3', Sales: 110 },
    { name: 'Week 4', Sales: 24 }
  ],
  April: [
    { name: 'Week 1', Sales: 98 },
    { name: 'Week 2', Sales: 120 },
    { name: 'Week 3', Sales: 75 },
    { name: 'Week 4', Sales: 125 }
  ],
  May: [
    { name: 'Week 1', Sales: 65 },
    { name: 'Week 2', Sales: 45 },
    { name: 'Week 3', Sales: 220 },
    { name: 'Week 4', Sales: 112 }
  ],
  June: [
    { name: 'Week 1', Sales: 55 },
    { name: 'Week 2', Sales: 170 },
    { name: 'Week 3', Sales: 92 },
    { name: 'Week 4', Sales: 85 }
  ],
};

const Graph = () => {
  const [selectedMonth, setSelectedMonth] = useState('January'); // Default selected month

  const handleChangeMonth = (event) => {
    setSelectedMonth(event.target.value);
  };

  const data = monthData[selectedMonth];

  return (
    <div className="card" style={{ 
      width: '660px',
      height: 400,
      margin: '20px auto',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
      backgroundColor: '#f5f5f5',
      position: 'relative',
      bottom: '450px',
      right: '137px'
    }}>
      <select className="form-select mb-4"
        value={selectedMonth} onChange={handleChangeMonth}
        style={{
          width: '20%',
          marginBottom: '10px',
          position: "relative",
          left: "30px"
        }}>
        {Object.keys(monthData).map(month => (
          <option key={month} value={month}>{month}</option>
        ))}
      </select>
      <label style={{
        position: "relative",
        bottom: "55px",
        left: "500px",
        fontWeight: "bold",
        letterSpacing: "1px"
      }}> Sales Value
      </label>

      <ResponsiveContainer width="100%" height={300} style={{ position: "relative", bottom: "20px" }}>
        <AreaChart
          data={data}
          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
        >
          {/* Omitting CartesianGrid component to remove all grid lines */}
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Area
            type="monotone"
            dataKey="Sales"
            stroke="#8884d8"
            strokeWidth={2}
            fill="rgba(0, 255, 255, 0.2)"
	    
            dot={{
              stroke: '#8884d8',
              fill: '#8884d8',
              r: 4
            }} />
        </AreaChart>
	
      </ResponsiveContainer>    
</div>
  );
};

export default Graph;
