import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer} from 'recharts';

const monthData = {
  January: { month: 'JAN', loss: 4000, profit: 2400 },
  February: { month: 'FEB', loss: 3000, profit: 1398 },
  March: { month: 'MAR', loss: 2000, profit: 9800 },
  April: { month: 'APR', loss: 2780, profit: 3908 },
  May: { month: 'MAY', loss: 1890, profit: 4800 },
  June: { month: 'JUN', loss: 2390, profit: 3800 },
  July: { month: 'JUL', loss: 3490, profit: 4300 },
  August: { month: 'AUG', loss: 3490, profit: 4300 },
  September: { month: 'SEP', loss: 3490, profit: 4300 },
  October: { month: 'OCT', loss: 3490, profit: 4300 },
  November: { month: 'NOV', loss: 3490, profit: 4300 },
  December: { month: 'DEC', loss: 3490, profit: 4300 },
};

const BarGraph = () => {
  const [selectedRange, setSelectedRange] = useState('firstSix'); // Default selected range

  const handleChangeRange = (event) => {
    setSelectedRange(event.target.value);
  };

  const getRangeData = () => {
    if (selectedRange === 'firstSix') {
      return Object.values(monthData).slice(0, 6);
    } else if (selectedRange === 'lastSix') {
      return Object.values(monthData).slice(6);
    }
    return [];
  };

  const data = getRangeData();

  return (
    <div className="card" style={{ 
      width: '1115px',
      position: 'relative',
      bottom: '440px',
      right: '-90px',
      height: '400px',
      margin: '20px auto',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
      backgroundColor: '#f5f5f5', // Light blue background color
    }}>
      <select className="form-select mb-4" value={selectedRange} onChange={handleChangeRange} style={{ width: '120px',position:"relative", left:"13px", marginBottom: '10px' }}>
        <option value="firstSix">Half way</option>
        <option value="lastSix"> 2nd Half</option>
      </select>
	
<label style={{position:"relative", bottom:"55px", left:"235px", fontWeight:"bold"}}>Profit & Expenses</label>
      <ResponsiveContainer width="100%" height={300} style={{position:"relative", bottom:"10px"}}>
        <BarChart data={data}>
          
          
	  <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="profit" name="Profit" fill="#82ca9d" />
          <Bar dataKey="loss" name="Loss" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    
</div>
  );
};

export default BarGraph;
