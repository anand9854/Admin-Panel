import React, { useState, useEffect } from "react";
import { Table, Button, ButtonToolbar } from "react-bootstrap";
import { getModule, deleteModule } from "../services/ModuleService";
import AddModuleModal from "./AddModuleModal";
import UpdateModuleModal from "./UpdateModuleModal";
import { FaTrashAlt } from 'react-icons/fa'
import { MdOutlineSystemUpdateAlt } from "react-icons/md";
import ClippedDrawer from '../Navigations/AppHead';


const Manage = () => {
  const [module, setModule] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [isUpdated, setIsUpdated] = useState(false);
  const [editmodule, setEditModule] = useState();
  const [editModalShow, setEditModalShow] = useState(false);

  useEffect(() => {
    let mounted = true;
    if (module.length && !isUpdated) {
      return;
    }
    getModule().then((data) => {
      if (mounted) {
        setModule(data);
      }
    });
    return () => {
      mounted = false;
      setIsUpdated(false);
    };
  }, [isUpdated, module]);

  const handleAdd = () => {
    setAddModalShow(true);
  };

  const handleUpdate = (mod) => {
    setEditModalShow(true);
    setEditModule(mod);
  };

  const handleDelete = (ID) => {
    if (window.confirm("Are you sure?")) {
      deleteModule(ID)
        .then((result) => {
          alert(result);
          setIsUpdated(true);
        })
        .catch((error) => {
          alert("Failed to Delete Record");
        });
    }
  };

  const AddModalClose = () => setAddModalShow(false);
  const EditModalClose = () => setEditModalShow(false);

  return (
    <div className="container-fluid">
      <ClippedDrawer/>
      <div className="row">
        <ButtonToolbar className="mb-3">
          <Button className="mr-2" variant="success" style={{position:"relative", left:"1200px",width:"10%", top:"80px"}}onClick={handleAdd}>
            Add Module
          </Button>{" "}
          <AddModuleModal show={addModalShow} onHide={AddModalClose} setUpdated={setIsUpdated} />
        </ButtonToolbar>

            <Table striped bordered hover className="react-bootstrap-table" style={{position:"relative", left:"200px", top:"80px",width:"84%"}}>
            <thead className="thead-dark text-center">
              <tr>
                <th>ID</th>
                <th>Module name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {module.map((mod) => (
                <tr key={mod.id}>
                  <td className="text-center">{mod.ID}</td>
                  <td className="text-center">{mod.Module_name}</td>
                  <td className="text-center">
                    <Button variant="danger" style={{ width: "50px" }} onClick={() => handleDelete(mod.ID)}>
                      <FaTrashAlt />
                    </Button>{" "}
                    <Button className="ml-2" variant="primary" style={{ width: "50px" }} onClick={() => handleUpdate(mod)}>
                      <MdOutlineSystemUpdateAlt />
                    </Button>{" "}
                    <UpdateModuleModal show={editModalShow} onHide={EditModalClose} module={editmodule} setUpdated={setIsUpdated} />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      
    </div>
  );
};

export default Manage;
