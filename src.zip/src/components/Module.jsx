import * as React from 'react';
import Grid from '@mui/material/Grid'; // Import Grid from Material-UI
import './cardbg.css';
import ClippedDrawer from '../Navigations/AppHead';
import Creditors from './Creditors';
import Suppliers from './Suppliers';
import Graph from './Graph';
import BarGraph from './BarGraph';
import Productsales from './Productsales';
export default function StatFullTemplate() {
  return (
    <div className="card_bg">
      <ClippedDrawer/>       
      
      <Grid container spacing={2} sx={{ paddingLeft: '300px', position:"relative", right:"145px", top:"125px"}}>
        <Grid item xs={6} style={{ paddingLeft: '50px', position:"relative", bottom:"33px", left:"15px" }}>
          <div className="card l-bg-cherry" style={{ width: "42%", height: "100px" }}>
            <div className="card-statistic-3 p-4">
              <div className="card-icon card-icon-large"><i className="fas fa-shopping-cart"></i></div>
              <div className="mb-4"> <h5 className="card-title mb-0"> Purchase Value </h5> </div>
              <div className="row align-items-center mb-2 d-flex">
                <div className="col-8"> <h6 className="d-flex align-items-center mb-0" style={{ position: "relative", bottom: "10px" }}> 3,243 </h6> </div>
              </div>
            </div>
          </div>
          <div className="card l-bg-cyan-dark" style={{ width: "42%", height: "100px",bottom:"130px", left:"920px" }}>
            <div className="card-statistic-3 p-4">
              <div className="card-icon card-icon-large"><i className="fas fa-users"></i></div>
              <div className="mb-4">
                <h5 className="card-title mb-0">Sales Value</h5>
              </div>
              <div className="row align-items-center mb-2 d-flex">
                <div className="col-8">
                  <h6 className="d-flex align-items-center mb-0" style={{ position: "relative", bottom: "10px" }}>
                    15.07k
                  </h6>
                </div>
              </div>
              
            </div>
          </div>                  
        <div className="card l-bg-blue-dark" style={{ width: "42%", height: "100px",bottom:"260px",left:"690px" }}>
            <div className="card-statistic-3 p-4">
              <div className="card-icon card-icon-large"><i className="fas fa-users"></i></div>
              <div className="mb-4">
                <h5 className="card-title mb-0">Cash Value</h5>
              </div>
              <div className="row align-items-center mb-2 d-flex">
                <div className="col-8">
                  <h6 className="d-flex align-items-center mb-0" style={{ position: "relative", bottom: "10px" }}>
                    15.07k
                  </h6>
                </div>
              </div>
            </div>
          </div>
        <div className="card l-bg-green-dark" style={{ width: "42%", height:"100px",bottom:"390px",left:"460px" }}>
            <div className="card-statistic-3 p-4">
              <div className="card-icon card-icon-large"><i className="fas fa-users"></i></div>
              <div className="mb-4">
                <h5 className="card-title mb-0">Credit Value</h5>
              </div>
              <div className="row align-items-center mb-2 d-flex">
                <div className="col-8">
                  <h6 className="d-flex align-items-center mb-0" style={{ position: "relative", bottom: "10px" }}>
                    15.07k
                  </h6>
                </div>
              </div>
            </div>
          </div>
        <div className="card l-bg-orange-dark" style={{ width: "42%", height: "100px",left:"230px",bottom:"520px" }}>
            <div className="card-statistic-3 p-4">
              <div className="card-icon card-icon-large"><i className="fas fa-users"></i></div>
              <div className="mb-4">
                <h5 className="card-title mb-0">Highest Bill</h5>
              </div>
              <div className="row align-items-center mb-2 d-flex">
                <div className="col-8">
                  <h6 className="d-flex align-items-center mb-0" style={{ position: "relative", bottom: "10px" }}>
                    15.07k
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </Grid>
      </Grid>
     
      <Graph/>
      <BarGraph/>
	<Productsales/>
	<Creditors/>
	<Suppliers/>
    </div>
    
);
}
