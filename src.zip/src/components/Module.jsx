import * as React from 'react';
import PropTypes from 'prop-types';
import Stack from '@mui/material/Stack';
import { styled, useThemeProps } from '@mui/material/styles';
import { Grid, Card, CardContent, Typography } from '@mui/material';
import { BarChart } from '@mui/x-charts/BarChart';
const StatRoot = styled('div', {
  name: 'MuiStat',
  slot: 'root',
})(({ theme, ownerState }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(0.6),
  padding: theme.spacing(2, 7),
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[2],
  letterSpacing: '-0.025em',
  fontWeight: '300',
  position: 'relative',
  top: '80px',
  left: '215px',	
  ...(ownerState.variant === 'outlined' && {
    border: `2px solid ${theme.palette.divider}`,
    boxShadow: 'none',
  }),
}));

const StatValue = styled('div', {
  name: 'MuiStat',
  slot: 'value',
})(({ theme }) => ({
  ...theme.typography.h3,
}));

const StatUnit = styled('div', {
  name: 'MuiStat',
  slot: 'unit',
})(({ theme }) => ({
  ...theme.typography.body2,
  color: theme.palette.text.secondary,
}));

const Stat = React.forwardRef(function Stat(inProps, ref) {
  const props = useThemeProps({ props: inProps, name: 'MuiStat' });
  const { value, unit, variant, ...other } = props;

  const ownerState = { ...props, variant };

  return (
    <StatRoot ref={ref} ownerState={ownerState} {...other}>
      <StatValue ownerState={ownerState}>{value}</StatValue>
      <StatUnit ownerState={ownerState}>{unit}</StatUnit>
    </StatRoot>
  );
});

Stat.propTypes = {
  unit: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  variant: PropTypes.oneOf(['outlined']),
};

export default function StatFullTemplate() {
  return (
<div>
    <Stack direction="row" spacing={2}>
        <Stat value="0.00" unit="Purchase value" variant='outlined' />
	<Stat value="0.00" unit="Credit value" variant="outlined" />
	<Stat value="0.00" unit="Sales value" variant='outlined' />
	<Stat value="0.00" unit="Cash value" variant='outlined' />
	<Stat value="0.00" unit="Highest Bill" variant='outlined' />
		
    </Stack>
<Grid container spacing={1}>
	<Grid item xs={12} md={12} lg={6}>
                <Card sx={{ borderRadius: '10px', position:"relative", top:"100px", width:"84%",left:"188px" }}>
                    <CardContent>
                        <Typography variant="h5" component="h2" align="center" gutterBottom sx={{ backgroundColor: 'lightblue', padding: '10px', borderTopLeftRadius: '10px', borderTopRightRadius: '10px', marginTop: '-16px', marginRight: '-16px', marginLeft: '-16px' }} style={{ fontFamily: 'Times New Roman', fontSize: '22px', backgroundColor: 'rgb(237, 231, 246)', color: 'rgb(94, 53, 177)', fontWeight: 'bold' }}>
                            Purchase Report
                        </Typography>
                        
                            <BarChart
				sx={{position:"absolute", top:"20px"}}
                                xAxis={[{ scaleType: 'band', data: ['group A', 'group B', 'group C'] }]}
                                series={[{ data: [4, 3, 5] }, { data: [1, 6, 3] }, { data: [2, 5, 6] }]}
                                width={570}
                                height={190}
                            />
                        
                    </CardContent>
                </Card>
            </Grid>
	<Grid item xs={12} md={12} lg={6}>
                <Card sx={{ borderRadius: '10px', position:"relative", top:"100px", width:"86%",left:"87px" }}>
                    <CardContent>
                        <Typography variant="h5" component="h2" align="center" gutterBottom sx={{ backgroundColor: 'lightblue', padding: '10px', borderTopLeftRadius: '10px', borderTopRightRadius: '10px', marginTop: '-16px', marginRight: '-16px', marginLeft: '-16px' }} style={{ fontFamily: 'Times New Roman', fontSize: '22px', backgroundColor: 'rgb(237, 231, 246)', color: 'rgb(94, 53, 177)', fontWeight: 'bold' }}>
                            Purchase Report
                        </Typography>
                        
                            <BarChart
				sx={{position:"absolute", top:"20px"}}
                                xAxis={[{ scaleType: 'band', data: ['group A', 'group B', 'group C'] }]}
                                series={[{ data: [4, 3, 5] }, { data: [1, 6, 3] }, { data: [2, 5, 6] }]}
                                width={570}
                                height={190}
                            />
                        
                    </CardContent>
                </Card>
            </Grid>
		
</Grid>
</div>
  );
}
