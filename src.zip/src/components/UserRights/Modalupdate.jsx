import React from "react";
import { Modal, Col, Row, Form, Button } from 'react-bootstrap';
import { updateUser } from '../../services/UserService';

const Modalupdate = (props) => {
    if (!props.right) {
        return null;
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = {
            Formname: e.target.elements.Formname.value,
            Add: e.target.elements.Add.checked,
            Delete: e.target.elements.Delete.checked,
            View: e.target.elements.View.checked,
            Post: e.target.elements.Post.checked,
            Menu: e.target.elements.Menu.checked,
            Others: e.target.elements.Others.checked
        };

        updateUser(props.right.ID, formData)
            .then((result) => {
                alert(result); // Display success message (if any) from API
                props.setUpdated(true); // Update parent component state

            })
            .catch((error) => {
                console.error('Error updating record:', error);
                alert("Failed to Update Record"); // Display error message
            });
    };

    return (
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Update Record
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row>
                        <Col sm={8}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="Formname">
                                    <Form.Label>Form name</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        name="Formname" 
                                        defaultValue={props.right.Formname}
                                        placeholder="Enter Form Name"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Add">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="Add" 
                                        defaultChecked={props.right.Add}
                                        label="Add"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Delete">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="Delete" 
                                        defaultChecked={props.right.Delete}
                                        label="Delete"
                                    />
                                </Form.Group>
                                <Form.Group controlId="View">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="View" 
                                        defaultChecked={props.right.View}
                                        label="View"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Post">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="Post" 
                                        defaultChecked={props.right.Post}
                                        label="Post"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Menu">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="Menu" 
                                        defaultChecked={props.right.Menu}
                                        label="Menu"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Others">
                                    <Form.Check 
                                        type="checkbox" 
                                        name="Others" 
                                        defaultChecked={props.right.Others}
                                        label="Others"
                                    />
                                </Form.Group>
                                <Button variant="primary" type="submit">
                                    Submit
                                </Button>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Modalupdate;
