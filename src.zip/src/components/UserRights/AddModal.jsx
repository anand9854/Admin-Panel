import React, { useState, useEffect } from 'react';
import { Modal, Col, Row, Form, Button } from 'react-bootstrap';
import { addUser } from '../../services/UserService';
import { getForms } from '../../services/FormService';

const AddModalform = (props) => {
    const [formData, setFormData] = useState({
        UserRole: '',
        Formnames: [], 
        Add: false,
        Delete: false,
        View: false,
        Post: false,
        Menu: false,
        Others: false
    });
    const [module, setModule] = useState([]);
    const [addAllChecked, setAddAllChecked] = useState(false); 
    const [submitting, setSubmitting] = useState(false); 

    useEffect(() => {
        fetchForms(); 
    }, []);

    const fetchForms = () => {
        getForms().then((data) => {
            setModule(data);
        }).catch(error => {
            console.error('Error fetching forms:', error);
        });
    };

    const handleChange = (e) => {
        const { name, value, checked, type } = e.target;
        if (name === 'AddAll') {
            setAddAllChecked(checked);
            if (checked) {
                const allFormnames = module.map(item => `${item.Modulename}-${item.Formname}`);
                setFormData(prevFormData => ({
                    ...prevFormData,
                    Formnames: allFormnames
                }));
            } else {
                setFormData(prevFormData => ({
                    ...prevFormData,
                    Formnames: []
                }));
            }
        } else if (name === 'Formname') {
            const selectedFormnames = Array.from(e.target.selectedOptions, option => option.value);
            setFormData(prevFormData => ({
                ...prevFormData,
                Formnames: selectedFormnames
            }));
        } else {
            setFormData(prevFormData => ({
                ...prevFormData,
                [name]: type === 'checkbox' ? checked : value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true); 

        try {
            for (const formname of formData.Formnames) {
                const data = {
                    UserRole: formData.UserRole,
                    Formname: formname,
                    Add: formData.Add,
                    Delete: formData.Delete,
                    View: formData.View,
                    Post: formData.Post,
                    Menu: formData.Menu,
                    Others: formData.Others
                };
                await addUser(data); 
            }

            alert(`Records added successfully: ${formData.Formnames.length}`);

            setFormData({
                UserRole: '',
                Formnames: [],
                Add: false,
                Delete: false,
                View: false,
                Post: false,
                Menu: false,
                Others: false
            });
            props.setUpdated(true); 
        } catch (error) {
            alert("Failed to Add Record");
            console.error('Error adding record:', error);
        } finally {
            setSubmitting(false); 
        }
    };

    return (
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Fill in the Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row className="justify-content-center">
                        <Col sm={6}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="UserRole">
                                    <Form.Label>UserRole</Form.Label>
                                    <Form.Control
                                        type="text"
                                        name="UserRole"
                                        value={formData.UserRole}
                                        onChange={handleChange}
                                        placeholder="Enter UserRole"
                                    />
                                </Form.Group>
                                <Form.Group controlId="Formname">
                                    <Form.Label>Select Form</Form.Label>
                                    <Form.Check
                                        type="checkbox"
                                        label="Add all"
                                        name="AddAll"
                                        checked={addAllChecked}
                                        onChange={handleChange}
                                    />
                                    <Form.Control
                                        as="select"
                                        name="Formname"
                                        value={formData.Formnames} 
                                        onChange={handleChange}
                                        disabled={addAllChecked} 
                                        multiple
                                    >
                                        {module.map((rid) => (
                                            <option key={rid.id} value={`${rid.Modulename}-${rid.Formname}`}>
                                                {rid.Modulename}-{rid.Formname}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>
                                <Button variant="primary" type="submit" disabled={submitting}>
                                    {submitting ? 'Submitting...' : 'Submit'}
                                </Button>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide} disabled={submitting}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default AddModalform;
