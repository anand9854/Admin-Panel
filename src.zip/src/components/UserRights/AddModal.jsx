import React, { useState, useEffect } from 'react';
import { Modal, Col, Row, Form, Button } from 'react-bootstrap';
import { addUser } from '../../services/UserService';
import { getForms } from '../../services/FormService';

const AddModalform = (props) => {
    const [formData, setFormData] = useState({
        UserRole:'',
        Formname:'',
        Add: false,
        Delete: false,
        View: false,
        Post: false,
        Menu: false,
        Others: false
    });
    const [module, setModule] = useState([]);
    const [isUpdated, setIsUpdated] = useState(false);

    useEffect(() => {
        let mounted = true;
        if (module.length && !isUpdated) {
            return;
        }
        getForms().then((data) => {
            if (mounted) {
                setModule(data);
            }
        });
        return () => {
            mounted = false;
            setIsUpdated(false);
        };
    }, [isUpdated, module]);

    const handleChange = (e) => {
        const { name, value, checked, type } = e.target;
        setFormData(prevFormData => ({
            ...prevFormData,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        addUser(formData).then(
            (result) => {
                console.log('Add User Result:', result);
                alert(result);
                props.setUpdated(true);
                setFormData({
                    UserRole:'',
                    Formname:'',
                    Add: false,
                    Delete: false,
                    View: false,
                    Post: false,
                    Menu: false,
                    Others: false
                });
            },
            (error) => {
                alert("Failed to Add Record");
                console.error('Error adding record:', error);
            }
        );
    };

    return (
        <div className="container">
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Fill in the Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row>
                        <Col sm={8}>
                            <Form onSubmit={handleSubmit}>
                                <Row>
                                    <Col sm={6}>
                                        <Form.Group controlId="Formname">
                                        <Form.Group controlId="UserRole" style={{position:"relative", bottom:"24px", left:"250px"}}>
                                            <Form.Label>UserRole</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="UserRole"
                                                value={formData.UserRole}
                                                onChange={handleChange}
                                                placeholder="Enter UserRole"
                                            />
                                        </Form.Group>   
                                            <Form.Label>Select Form</Form.Label>
                                            <Form.Control
                                                as="select"
                                                name="Formname"
                                                value={formData.Formname}
                                                onChange={handleChange}
                                                placeholder="Select form name"
                                            >
                                                <option value="" disabled>Select from Module</option>
                                                {module.map((rid) => (
                                                    <option key={rid.id} value={`${rid.Modulename}-${rid.Formname}`}>
                                                        {rid.Modulename}-{rid.Formname}
                                                    </option>
                                                ))}
                                            </Form.Control>
                                        </Form.Group>
                                    </Col>
                                    <Col sm={6} className="or-text">
                                        <div className="or-text" style={{position:"relative", left:"70px"}}>OR</div>
                                        <Form.Group controlId="FormnameText" style={{position:"relative", bottom:"24px", left:"250px"}}>
                                            <Form.Label>Enter Form Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="Formname"
                                                onChange={handleChange}
                                                placeholder="Enter form name"
                                            />
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col sm={3}>
                                        <Form.Group controlId="Add">
                                            <Form.Check
                                                type="checkbox"
                                                name="Add"
                                                label="Add"
                                                checked={formData.Add}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                    <Col sm={3}>
                                        <Form.Group controlId="Delete">
                                            <Form.Check
                                                type="checkbox"
                                                name="Delete"
                                                label="Delete"
                                                checked={formData.Delete}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                    <Col sm={3}>
                                        <Form.Group controlId="View">
                                            <Form.Check
                                                type="checkbox"
                                                name="View"
                                                label="View"
                                                checked={formData.View}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                    <Col sm={3}>
                                        <Form.Group controlId="Post">
                                            <Form.Check
                                                type="checkbox"
                                                name="Post"
                                                label="Post"
                                                checked={formData.Post}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col sm={3}>
                                        <Form.Group controlId="Menu">
                                            <Form.Check
                                                type="checkbox"
                                                name="Menu"
                                                label="Menu"
                                                checked={formData.Menu}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                    <Col sm={3}>
                                        <Form.Group controlId="Others">
                                            <Form.Check
                                                type="checkbox"
                                                name="Others"
                                                label="Others"
                                                checked={formData.Others}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Button variant="primary" type="submit">
                                    Submit
                                </Button>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={props.onHide}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default AddModalform;

