import React, { useState, useEffect } from 'react';
import { Table, Button } from 'react-bootstrap';
import { getUser, deleteUser, updateUser } from '../../services/UserService';
import { RiDeleteBin5Line } from 'react-icons/ri';
import { FaEdit } from 'react-icons/fa';
import AddModalform from './AddModal';
import Modalupdate from './Modalupdate';
import ClippedDrawer from '../../Navigations/AppHead';
import LoupeIcon from '@mui/icons-material/Loupe';

const UserManagement = () => {
    const [moduleform, setModuleform] = useState([]);
    const [addModalShow, setAddModalShow] = useState(false);
    const [editModalShow, setEditModalShow] = useState(false);
    const [editModuleform, setEditModuleform] = useState(null);
    const [isUpdated, setIsUpdated] = useState(false);
    const [checkboxStates, setCheckboxStates] = useState({});

    useEffect(() => {
        let mounted = true;
        if (moduleform.length && !isUpdated) {
            return;
        }
        getUser().then(data => {
            if (mounted) {
                setModuleform(data);
                const initialStates = data.reduce((acc, cur) => {
                    acc[cur.ID] = {
                        Add: cur.Add || false,
                        Delete: cur.Delete || false,
                        View: cur.View || false,
                        Post: cur.Post || false,
                        Menu: cur.Menu || false,
                        Others: cur.Others || false,
                    };
                    return acc;
                }, {});
                setCheckboxStates(initialStates);
            }
        });
        return () => {
            mounted = false;
            setIsUpdated(false);
        };
    }, [isUpdated, moduleform]);

    const handleUpdate = (e, rid) => {
        e.preventDefault();
        setEditModuleform(rid);
        setEditModalShow(true);
    };

    const handleAdd = (e) => {
        e.preventDefault();
        setAddModalShow(true);
    };

    const handleDelete = (e, ID) => {
        if (window.confirm('Are you sure?')) {
            e.preventDefault();
            deleteUser(ID).then(
                (result) => {
                    alert(result);
                    setIsUpdated(true);
                },
                (error) => {
                    alert("Failed to Delete Record");
                }
            );
        }
    };

    const handleCheckboxChange = (e, id) => {
        const { name, checked } = e.target;
        setCheckboxStates(prevState => ({
            ...prevState,
            [id]: {
                ...prevState[id],
                [name]: checked,
            },
        }));
    };

    const handleSubmit = () => {
        Object.keys(checkboxStates).forEach((id) => {
            const updatedRights = {
                ...moduleform.find(rid => rid.ID === parseInt(id)),
                ...checkboxStates[id]
            };
            updateUser(updatedRights.ID, updatedRights).then(
                (result) => {
                    console.log(`Updated ${updatedRights.ID} successfully: ${result}`);
                },
                (error) => {
                    console.error(`Failed to update ${updatedRights.ID}: ${error}`);
                }
            );
        });
        alert("Changes saved!");
        setIsUpdated(true);
    };

    let AddModelClose = () => setAddModalShow(false);
    let EditModelClose = () => {
        setEditModuleform(null);
        setEditModalShow(false);
    };

    // const renderIcon = (value) => {
    //     return value ? <FaCheckCircle style={{ color: 'green' }} /> : <FaTimesCircle style={{ color: 'red' }} />;
    // };

    return (
        <div className="container-fluid side-container">
            <ClippedDrawer />
            <div className="row side-row">
                <p id="manage_form"></p>
                <Button variant="success" onClick={handleAdd} style={{ position: "relative", top: "5px", width: '5.7%', left: "1230px" }}>
                    <LoupeIcon /><label style={{ position: "relative", top: "2px", left: "5px" }}>Add</label>
                </Button>{" "}
                <Button variant="primary" onClick={handleSubmit} style={{ position: "relative", top: "5px", width: '10%', left: "500px" }}>
                    Submit
                </Button>{" "}
                <AddModalform
                    show={addModalShow}
                    setUpdated={setIsUpdated}
                    onHide={AddModelClose}
                />
                <Table striped bordered hover className="react-bootstrap-table"
                    style={{ position: "relative", left: "169px", top: "30px", width: "88%" }}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User Role</th>
                            <th>Form Name</th>
                            <th>Add</th>
                            <th>Delete</th>
                            <th>View</th>
                            <th>Post</th>
                            <th>Menu</th>
                            <th>Others</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {moduleform.map((rid) =>
                            <tr key={rid.id}>
                                <td>{rid.ID}</td>
                                <td>{rid.UserRole}</td>
                                <td>{rid.Formname}</td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Add"
                                        checked={checkboxStates[rid.ID]?.Add || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td><input
                                        type="checkbox"
                                        name="Delete"
                                        checked={checkboxStates[rid.ID]?.Delete || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                    </td>
                                <td><input
                                        type="checkbox"
                                        name="View"
                                        checked={checkboxStates[rid.ID]?.View || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    /></td>
                                <td><input
                                        type="checkbox"
                                        name="Post"
                                        checked={checkboxStates[rid.ID]?.Post || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    /></td>
                                <td><input
                                        type="checkbox"
                                        name="Menu"
                                        checked={checkboxStates[rid.ID]?.Menu || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    /></td>
                                <td><input
                                        type="checkbox"
                                        name="Others"
                                        checked={checkboxStates[rid.ID]?.Others || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    /></td>
                                <td>
                                    <Button className="mr-2" variant="danger" onClick={event => handleDelete(event, rid.ID)}>
                                        <RiDeleteBin5Line />
                                    </Button>
                                    <span>&nbsp;&nbsp;&nbsp;</span>
                                    <Button className="mr-2" variant="primary" onClick={event => handleUpdate(event, rid)}>
                                        <FaEdit />
                                    </Button>
                                    <Modalupdate
                                        show={editModalShow}
                                        right={editModuleform}
                                        setUpdated={setIsUpdated}
                                        onHide={EditModelClose}
                                    /> 
                                </td>
                            </tr>
                        )}
                    </tbody>
                </Table>
            </div>
        </div>
    );
};

export default UserManagement;
