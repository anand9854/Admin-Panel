import React, { useState, useEffect } from 'react';
import { Table, Button, Dropdown } from 'react-bootstrap';
import { getUser, deleteUser, updateUser } from '../../services/UserService';
import { RiDeleteBin5Line } from 'react-icons/ri';
import { FaEdit } from 'react-icons/fa';
import AddModalform from './AddModal';
import Modalupdate from './Modalupdate';
import ClippedDrawer from '../../Navigations/AppHead';
import LoupeIcon from '@mui/icons-material/Loupe';
import { MdFilterAlt } from "react-icons/md";

const UserManagement = () => {
    const [moduleform, setModuleform] = useState([]);
    const [addModalShow, setAddModalShow] = useState(false);
    const [editModalShow, setEditModalShow] = useState(false);
    const [editModuleform, setEditModuleform] = useState(null);
    const [isUpdated, setIsUpdated] = useState(false);
    const [checkboxStates, setCheckboxStates] = useState({});
    const [selectedUserRole, setSelectedUserRole] = useState('');
    const [filteredModuleform, setFilteredModuleform] = useState([]);
    const [userRolesOptions, setUserRolesOptions] = useState([]);

    useEffect(() => {
        let mounted = true;
        if (moduleform.length && !isUpdated) {
            return;
        }
        getUser().then(data => {
            if (mounted) {
                setModuleform(data);
                setFilteredModuleform(data);
                const initialStates = data.reduce((acc, cur) => {
                    acc[cur.ID] = {
                        Add: cur.Add || false,
                        Delete: cur.Delete || false,
                        View: cur.View || false,
                        Post: cur.Post || false,
                        Menu: cur.Menu || false,
                        Others: cur.Others || false,
                    };
                    return acc;
                }, {});
                setCheckboxStates(initialStates);

                const uniqueRoles = Array.from(new Set(data.map(item => item.UserRole)));
                setUserRolesOptions(uniqueRoles);
            }
        });
        return () => {
            mounted = false;
            setIsUpdated(false);
        };
    }, [isUpdated, moduleform]);

    useEffect(() => {
        if (selectedUserRole === '') {
            setFilteredModuleform(moduleform);
        } else {
            const filteredData = moduleform.filter(item => item.UserRole === selectedUserRole);
            setFilteredModuleform(filteredData);
        }
    }, [selectedUserRole, moduleform]);

    const handleRoleSelect = (role) => {
        setSelectedUserRole(role);
    };

    const handleCheckboxChange = (e, id) => {
        const { name, checked } = e.target;
        setCheckboxStates(prevState => ({
            ...prevState,
            [id]: {
                ...prevState[id],
                [name]: checked,
            },
        }));
    };

    const handleSubmit = () => {
        Object.keys(checkboxStates).forEach((id) => {
            const updatedRights = {
                ...moduleform.find(rid => rid.ID === parseInt(id)),
                ...checkboxStates[id]
            };
            updateUser(updatedRights.ID, updatedRights).then(
                (result) => {
                    console.log(`Updated ${updatedRights.ID} successfully: ${result}`);
                },
                (error) => {
                    console.error(`Failed to update ${updatedRights.ID}: ${error}`);
                }
            );
        });
        alert("Changes saved!");
        setIsUpdated(true);
    };

    const handleDelete = (e, ID) => {
        if (window.confirm('Are you sure?')) {
            e.preventDefault();
            deleteUser(ID).then(
                (result) => {
                    alert(result);
                    setIsUpdated(true);
                },
                (error) => {
                    alert("Failed to Delete Record");
                }
            );
        }
    };

    const handleUpdate = (e, rid) => {
        e.preventDefault();
        setEditModuleform(rid);
        setEditModalShow(true);
    };

    const AddModelClose = () => setAddModalShow(false);
    
    const EditModelClose = () => {
        setEditModuleform(null);
        setEditModalShow(false);
    };

    return (
        <div className="container-fluid side-container">
            <ClippedDrawer /> 
            <div className="row side-row">
                <Button variant="success" onClick={() => setAddModalShow(true)} style={{ position: "relative", top: "20px", width: '5.7%', left: "1230px" }}>
                    <LoupeIcon /><label style={{ position: "relative", top: "2px", left: "5px" }}>Add</label>
                </Button>{" "}
                <Button variant="primary" onClick={() => handleSubmit()} style={{ position: "relative", top: "20px", width: '5.7%', left: "1070px" }}>
                    Submit
                </Button>{" "}
                <AddModalform
                    show={addModalShow}
                    setUpdated={setIsUpdated}
                    onHide={AddModelClose}
                />
                <Table striped bordered hover className="react-bootstrap-table" style={{ position: "relative", left: "169px", top: "40px", width: "88%" }}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>
                            <label >User Role</label>
                                <Dropdown style={{width:"10%",position:"relative", left:"20px", height:"4px", bottom:"4px"}}>
                                
                                    <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components">
                                    <MdFilterAlt/>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        {userRolesOptions.map((option, index) => (
                                            <Dropdown.Item key={index} onClick={() => handleRoleSelect(option)}>
                                                {option}
                                            </Dropdown.Item>
                                        ))}
                                    </Dropdown.Menu>
                                </Dropdown>
                                
                            </th>
                            <th>Form Name</th>
                            <th>Add</th>
                            <th>Delete</th>
                            <th>View</th>
                            <th>Post</th>
                            <th>Menu</th>
                            <th>Others</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredModuleform.map((rid) =>
                            <tr key={rid.id}>
                                <td>{rid.ID}</td>
                                <td>{rid.UserRole}</td>
                                <td>{rid.Formname}</td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Add"
                                        checked={checkboxStates[rid.ID]?.Add || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Delete"
                                        checked={checkboxStates[rid.ID]?.Delete || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="View"
                                        checked={checkboxStates[rid.ID]?.View || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Post"
                                        checked={checkboxStates[rid.ID]?.Post || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Menu"
                                        checked={checkboxStates[rid.ID]?.Menu || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="Others"
                                        checked={checkboxStates[rid.ID]?.Others || false}
                                        onChange={(e) => handleCheckboxChange(e, rid.ID)}
                                    />
                                </td>
                                <td>
                                    <Button className="mr-2" variant="danger" onClick={event => handleDelete(event, rid.ID)}>
                                        <RiDeleteBin5Line />
                                    </Button>
                                    <Button className="mr-2" variant="primary" onClick={event => handleUpdate(event, rid)}>
                                        <FaEdit />
                                    </Button>
                                    <Modalupdate
                                        show={editModalShow}
                                        right={editModuleform}
                                        setUpdated={setIsUpdated}
                                        onHide={EditModelClose}
                                    />
                                </td>
                            </tr>
                        )}
                    </tbody>
                </Table>
            </div>
        </div>
    );
};

// Custom toggle component for Dropdown
const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <Button
        ref={ref}
        onClick={(e) => {
            e.preventDefault();
            onClick(e);
        }}
    >
        {children}
    </Button>
));

export default UserManagement;
