import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';
import { getModule} from '../services/ModuleService';
import "../App.css";

const Students = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
   let mounted = true;
   getModule()
     .then(data => {
       if(mounted) {
         setStudents(data)
       }
     })
   return () => mounted = false;
 }, [])

  return(
   <div className="container-fluid side-container">
   <div className="row side-row" >
    <p id="before-table"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
        <thead>
            <tr>
            <th>ID</th>
            <th>Module Name</th>
            </tr>
        </thead>
        <tbody>
            {students.map((mod) =>
            <tr key={mod.ID}>
		<td>{mod.ID}</td>
                <td>{mod.Module_name}</td>
                

            </tr>)}
        </tbody>
    </Table>
    </div>
  </div>
  );
};

export default Students;