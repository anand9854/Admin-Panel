import React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import LinearProgress from '@mui/material/LinearProgress';

import yogurt from './images/yogurt.jpg';
import IcecreamSandwich from './images/IcecreamSandwich.jpg';
import eclair from './images/eclair.jpg';
import cupcake from './images/cupcake.jpg';
import gingerbread from './images/gingerbread.jpg';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    position: 'sticky',
    top: 0,
    zIndex: 1,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

// Update createData to include image paths
function createData(name, Revenue, Credit, image) {
  const revenuePercentage = (Credit / Revenue) * 100;
  return { name, Revenue, Credit, revenuePercentage, image };
}

const rows = [
  createData('Frozen yoghurt', 159, 79.0, yogurt),
  createData('Ice cream sandwich', 237, 55.0, IcecreamSandwich),
  createData('Eclair', 262, 16.0, eclair),
  createData('Cupcake', 305, 113.7, cupcake),
  createData('Gingerbread', 356, 96.0, gingerbread),
];

const Productsales = () => {
  return (
    <TableContainer component={Paper} sx={{ position: "relative", height: "400px", width: "32%", right: "-895px", bottom: "1290px", overflow: 'auto' }}>
      <style>
        {`
          /* Custom scrollbar styles */
          .MuiTableContainer-root::-webkit-scrollbar {
            width: 12px;
          }

          .MuiTableContainer-root::-webkit-scrollbar-thumb {
            background-color: #888;
            border-radius: 6px;
            border: 3px solid #f5f5f5;
          }

          .MuiTableContainer-root::-webkit-scrollbar-thumb:hover {
            background-color: #555;
          }

          .MuiTableContainer-root::-webkit-scrollbar-track {
            background-color: #f5f5f5;
            border-radius: 6px;
          }
        `}
      </style>
      <Table aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>Best Selling Products</StyledTableCell>
            <StyledTableCell align="right">Revenue&nbsp;INR</StyledTableCell>
            <StyledTableCell align="right">Revenue&nbsp;(%)</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell component="th" scope="row" style={{ display: 'flex', alignItems: 'center' }}>
                <img src={row.image} alt={row.name} style={{ width: 50, height: 50, marginRight: 10 }} />
                {row.name}
              </StyledTableCell>
              <StyledTableCell align="right">{row.Revenue}</StyledTableCell>
              <StyledTableCell align="right">
                <LinearProgress variant="determinate" value={row.revenuePercentage} sx={{ width: "63%", position: "relative", left: "25px" }} />
                {row.revenuePercentage.toFixed(2)}%
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default Productsales;
