import React, { useState } from 'react';
import './table.css'; // Assuming you have your CSS for table styling here
import { FaArrowRight, FaArrowLeft } from "react-icons/fa";
import "./bg.css";
const Suppliers = () => {
  // Sample data
  const suppliersData = [
    { id: 1, name: 'Alfreds Futterkiste', contact: '+91 7358883876', remainingAmount: '2000 INR' },
    { id: 2, name: 'Roy', contact: '+91 9469992376', remainingAmount: '300 INR' },
    { id: 3, name: 'Brasius', contact: '+91 9247973876', remainingAmount: '400 INR' },
    { id: 4, name: 'Lucas', contact: '+91 7245973876', remainingAmount: '5006 INR' },
    { id: 5, name: 'Brax', contact: '+91 9997973876', remainingAmount: '1123 INR' },
    { id: 6, name: 'Max', contact: '+91 7877973876', remainingAmount: '112 INR' },
    { id: 7, name: 'Alex', contact: '+91 9248873876', remainingAmount: '223 INR' },
    { id: 8, name: 'Payne', contact: '+91 9245783876', remainingAmount: '4000 INR' },
    { id: 9, name: 'Sathya', contact: '+91 7358864424', remainingAmount: '0 INR' },
    { id: 10, name: 'Tom', contact: '+91 7247973876', remainingAmount: '122 INR' },
  ];

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  // Logic to calculate total pages
  const totalPages = Math.ceil(suppliersData.length / itemsPerPage);

  // Function to handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  // Function to handle items per page change
  const handleItemsPerPageChange = (perPage) => {
    setItemsPerPage(perPage);
    setCurrentPage(1); // Reset to first page when items per page changes
  };

  // Calculate current items to display
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = suppliersData.slice(startIndex, endIndex);

  return (
   
    <div className="card" style={{ width: '40%', position: 'relative', bottom: '1230px', right: '-780px', padding: '20px', boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)', backgroundColor: '#f5f5f5' }}>
      <h5 style={{ textAlign: 'center', marginBottom: '20px' }}>Suppliers List</h5>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Remaining Amount</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map((supplier, index) => (
            <tr key={supplier.id}>
              <td>{startIndex + index + 1}</td>
              <td>{supplier.name}</td>
              <td>{supplier.contact}</td>
              <td>{supplier.remainingAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button style={{position:"relative", top:"10px"}} type="button" className="btn btn-primary" onClick={() => handlePageChange(currentPage > 1 ? currentPage - 1 : currentPage)}>
          <FaArrowLeft />
        </button>
        <span style={{position:"relative" ,top:"17px"}}>
          Page {currentPage} of {totalPages}
        </span>
        <button style={{position:"relative", top:"10px"}} type="button" className="btn btn-primary" onClick={() => handlePageChange(currentPage < totalPages ? currentPage + 1 : currentPage)}>
          <FaArrowRight />
        </button>
        <label style={{ position:"relative", top:"17px",fontWeight: "bold", marginLeft: "20px" }}>No of Rows to Display:</label>
        <select style={{ position:"relative", top:"10px"}} value={itemsPerPage} onChange={(e) => handleItemsPerPageChange(parseInt(e.target.value))}>
          <option value={5}>5 per page</option>
          <option value={10}>10 per page</option>
          <option value={25}>25 per page</option>
        </select>
      </div>
    </div>
	
  );
};

export default Suppliers;
