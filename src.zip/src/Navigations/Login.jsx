import axios from "axios";
import { useState } from "react";
import { Navigate } from "react-router-dom";
import Sheet from '@mui/joy/Sheet';
import "./bg.css";
const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    

    const submit = async (e) => {
        e.preventDefault();

        const user = {
            username: username,
            password: password
        };

	try {        
            const { data } = await axios.post('http://localhost:8000/token/', user, {headers: {
                    'Content-Type': 'application/json'
               }}, {withCredentials: true});

            console.log(data);

            localStorage.clear();
            localStorage.setItem('access_token', data.access);
            localStorage.setItem('refresh_token', data.refresh);
            axios.defaults.headers.common['Authorization'] = `Bearer ${data['access']}`;
	    window.location.href = '/dashboard'        
	} catch (error) {
		console.error('Login error: ', error);
		alert('Invalid Username or password. Please try again.');
		setPassword('');
	}

    };

    return (
        <div className="bg-layer">
            <div className="Auth-form-container">
                <Sheet color="neutral" variant="soft" sx={{ position: "relative", top: "100px", right: "470px", width: "165%", height: "400px", padding: "5px", borderRadius: "20px" }}>
                    <form className="Auth-form" style={{ width: "91%", position: "relative", top: "37px", left: "17px" }} onSubmit={submit}>
                        <div className="Auth-form-content">
                            <h2 className="Auth-form-title" style={{ textAlign: "center", position:"relative", bottom:"5px" }}>Login</h2>
                            <div className="form-group d-grid gap-2 mt-3">
                                <label>Username :</label>
                                <input
                                    className="form-control mt-1"
                                    placeholder="Enter Username"
                                    name='username'
                                    type='text'
                                    value={username}
                                    required
                                    onChange={e => setUsername(e.target.value)}
                                />
                            </div>
					
                            <div className="form-group d-grid gap-2 mt-3" >
                                <label>Password :</label>
                                <input
                                    name='password'
                                    type="password"
                                    className="form-control mt-1"
                                    placeholder="Enter password"
                                    value={password}
                                    required
                                    onChange={e => setPassword(e.target.value)}
                                />
                            </div>
                            <div className="d-grid gap-2 mt-3">
                                <button type="submit" className="btn btn-success">
                                    Submit
                                </button>
                            </div>
                     </div>
                    </form>
                </Sheet>
            </div>
        </div>
    );
};

export default Login;
