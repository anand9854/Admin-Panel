import axios from 'axios';

// Function to fetch forms
export function getForms() {
    return axios.get("http://127.0.0.1:8000/Forms/")
        .then(response => response.data);
}

// Function to delete a form by ID
export function deleteForms(ID) {
    return axios.delete(`http://127.0.0.1:8000/Forms/${ID}/`, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    }).then(response => response.data);
}

// Function to add a new form
export function addForms(module_form) {
    return axios.post("http://127.0.0.1:8000/Forms/", {
        ID: null,
        Modulename: module_form.Modulename.value,
        Formname: module_form.Formname.value,
        Formcode: module_form.Formcode.value
    }).then(response => response.data);
}

// Function to update an existing form by ID
export function updateForms(fid, module_form) {
    return axios.put(`http://127.0.0.1:8000/Forms/${fid}/`, {
        ID: null,
        Modulename: module_form.Modulename.value,
        Formname: module_form.Formname.value,
        Formcode: module_form.Formcode.value
    }).then(response => response.data);
}
