import axios from 'axios';
	
	
export function getForms() {

	return axios.get("http://127.0.0.1:8000/Forms/").then(response => response.data)
}

export function deleteForms(ID){
	return axios.delete("http://127.0.0.1:8000/Forms/" + ID + "/", {
	method: "DELETE",
	header: {
		'Accept':'application/json',
		'Content-Type':'application/json'
	}
	
       }).then(response => response.data)

      }


export function addForms(module_form) {
	return axios.post("http://127.0.0.1:8000/Forms/", {
	ID:null,
	Modulename:module_form.Modulename.value,
	Formname:module_form.Formname.value,
	Formcode:module_form.Formcode.value
	}).then(response => response.data)
}



export function updateForms(fid, module_form) {

	return axios.put("http://127.0.0.1:8000/Forms/" + fid + '/',{
	ID:null,
	Modulename:module_form.Modulename.value,
	Formname:module_form.Formname.value,
	Formcode:module_form.Formcode.value
	}).then(response => response.data)
}





