import axios from 'axios';

export function getUser() {
    return axios.get('http://127.0.0.1:8000/Rights/')
        .then(response => response.data);
}

export function addUser(right) {
    
    const postData = {
        ID: null,  
        UserRole: right.UserRole,  
        Formname: right.Formname,  
        Add: right.Add,
        Delete: right.Delete,
        View: right.View,
        Post: right.Post,
        Menu: right.Menu,
        Others: right.Others
    };

    return axios.post("http://127.0.0.1:8000/Rights/", postData)
        .then(response => response.data)
        .catch(error => {
            console.error('Error adding user rights:', error);
            throw error; 
        });
}
   
export function updateUser(rid, right) {
    const formData = {
        ID: null,
        UserRole: right.UserRole,
        Formname: right.Formname,
        Add: right.Add,
        Delete: right.Delete,
        View: right.View,
        Post: right.Post,
        Menu: right.Menu,
        Others: right.Others
    };

    return axios.put(`http://127.0.0.1:8000/Rights/${rid}/`, formData)
        .then(response => response.data)
        .catch(error => {
            console.error('Error updating user:', error);
            throw error; 
        });
}

export function deleteUser(ID) {
    return axios.delete(`http://127.0.0.1:8000/Rights/${ID}/`, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.data);
}
