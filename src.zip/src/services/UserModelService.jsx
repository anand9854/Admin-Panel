import axios from 'axios'

export function  getUserModel(){
	return axios.get('http://127.0.0.1:8000/User/').then(response => response.data)
}

export function addUserModel(module){
	return axios.post('http://127.0.0.1:8000/User/',{
		ID:null,
		Username:module.Username.value,
        Password:module.Password.value,
	})
	.then(response =>response.data)
}

// export function updateUserModel(modid, module) {
// 	return axios.put('http://127.0.0.1:8000/User/' + modid + "/",{
// 		ID:null,
// 	    Username:module.Username.value,
//         Password:module.Password.value,
// 	})
// 	.then(response =>response.data)
// }
export function updateUserModel(modid, module) {
    const formData = {
        ID: null,
        Username: module.Username,
        Password: module.Password,
    };

    return axios.put(`http://127.0.0.1:8000/User/${modid}/`, formData)
        .then(response => response.data)
        .catch(error => {
            console.error('Error updating user:', error);
            throw error; 
        });
}
export function deleteUserModel(ID){
	return axios.delete('http://127.0.0.1:8000/User/' + ID + "/",{
		method: "DELETE",
		header:{
			'Accept':'application/json',
			'Content-Type':'application/json'
		}
	})
	.then(response =>response.data)
}