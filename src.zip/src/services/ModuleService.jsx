import axios from 'axios'

export function  getModule(){
	return axios.get('http://127.0.0.1:8000/Module_Master/').then(response => response.data)
}

export function addModule(module){
	return axios.post('http://127.0.0.1:8000/Module_Master/',{
		ID:null,
		Module_name:module.Module_name.value,
	})
	.then(response =>response.data)
}

export function updateModule(modid, module) {
	return axios.put('http://127.0.0.1:8000/Module_Master/' + modid + "/",{
		Module_name:module.Module_name.value,
	})
	.then(response =>response.data)
}

export function deleteModule(ID){
	return axios.delete('http://127.0.0.1:8000/Module_Master/' + ID + "/",{
		method: "DELETE",
		header:{
			'Accept':'application/json',
			'Content-Type':'application/json'
		}
	})
	.then(response =>response.data)
}